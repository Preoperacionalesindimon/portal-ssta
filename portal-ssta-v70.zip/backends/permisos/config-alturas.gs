/* ============================================================
   config-alturas.gs — Lo ÚNICO propio del permiso de Trabajo en Alturas
   ------------------------------------------------------------
   Va junto a core.gs dentro del mismo proyecto de Apps Script.
   core.gs es idéntico en los cinco permisos; este archivo es el que
   los diferencia.

   En Apps Script todos los archivos .gs de un proyecto comparten el
   mismo ámbito global, así que core.gs ve estas constantes sin
   necesidad de importar nada.
   ============================================================ */

const PERMISO_NOMBRE = 'Trabajo en Alturas';
const PERMISO_CODIGO = 'SSTA-F-116';

// Debe ser IDÉNTICO al API_TOKEN de config.js en el sitio web.
// Para rotarlo, ver el procedimiento en el README.
const API_TOKEN = 'xSiVfEUE1t0l5RI3lD7PJp2RPIa7H9M5XenSm8P1';
